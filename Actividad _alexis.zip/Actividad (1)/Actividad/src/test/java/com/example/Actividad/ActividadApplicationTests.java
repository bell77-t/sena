package com.example.Actividad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActividadApplicationTests {

	@Test
	void contextLoads() {
	}

}
